import java.io.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.json.JSONObject;

@WebServlet("/SendSurvey")
public class SendSurvey extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/plain");
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);

        JSONObject appointment = new JSONObject(sb.toString());

        String surveyData =
                "New Appointment from MBG Website\n\n" +
                "Name: " + appointment.getString("name") + "\n" +
                "Date: " + appointment.getString("date") + "\n" +
                "Time: " + appointment.getString("time") + "\n" +
                "Service: " + appointment.getString("service");

        // ⚠️ Use environment variables, do NOT hardcode password
        final String username = System.getenv("mbggangtry@gmail.com");
        final String password = System.getenv("johnjeffreymasangkay");

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
            new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(username));
            message.setSubject("New Appointment - MBG Website");
            message.setText(surveyData);

            Transport.send(message);
            response.getWriter().println("Appointment sent successfully!");
        } catch (MessagingException e) {
            e.printStackTrace();
            response.getWriter().println("Error sending appointment.");
        }
    }
}