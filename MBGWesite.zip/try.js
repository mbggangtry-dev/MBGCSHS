// ================= AUTHENTICATION =================
function signup() {
    const user = document.getElementById("signupUsername").value.trim();
    const pass = document.getElementById("signupPassword").value.trim();

    if (!user || !pass) return alert("Fill all fields");
    if (localStorage.getItem("mbc_" + user)) return alert("Username already exists!");

    localStorage.setItem("mbc_" + user, pass);
    localStorage.setItem("mbcUser", user);

    showDashboard();
    appendBot(`Welcome ${user}! Click 'Start' to schedule your appointment.`);
}

function login() {
    const user = document.getElementById("loginUsername").value.trim();
    const pass = document.getElementById("loginPassword").value.trim();
    const storedPass = localStorage.getItem("mbc_" + user);

    if (storedPass && pass === storedPass) {
        localStorage.setItem("mbcUser", user);
        showDashboard();
        appendBot(`Welcome ${user}! Click 'Start' to schedule your appointment.`);
    } else alert("Invalid credentials!");
}

// ================= SHOW/HIDE FORMS =================
function showSignup() {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("signupForm").style.display = "block";
}

function showLogin() {
    document.getElementById("signupForm").style.display = "none";
    document.getElementById("loginForm").style.display = "block";
}

function logout() {
    localStorage.removeItem("mbcUser");
    document.getElementById("dashboard").style.display = "none";
    document.getElementById("authCard").style.display = "block";
    document.getElementById("chatContainer").innerHTML = `
        <div class="bot-message">Hi! 👋 Welcome to MBG Cainta Senior High School. Click 'Start' to schedule your appointment.</div>
        <div id="startBtnContainer"><button onclick="startAppointment()">START</button></div>
    `;
}

// ================= DASHBOARD =================
function showDashboard() {
    document.getElementById("authCard").style.display = "none";
    document.getElementById("dashboard").style.display = "block";
}

// ================= CHAT SYSTEM =================
let step = 0;
let appointment = { name: "", date: "", time: "", service: "" };

function appendBot(text) {
    const chat = document.getElementById("chatContainer");
    chat.innerHTML += `<div class="bot-message">${text}</div>`;
    chat.scrollTop = chat.scrollHeight;
}

function appendUser(text) {
    const chat = document.getElementById("chatContainer");
    chat.innerHTML += `<div class="user-message">${text}</div>`;
    chat.scrollTop = chat.scrollHeight;
}

// ================= START APPOINTMENT =================
function startAppointment() {
    // Remove start button completely
    const startBtnContainer = document.getElementById("startBtnContainer");
    if (startBtnContainer) startBtnContainer.remove();

    appendBot("Let's schedule your appointment. What's your full name?");
    step = 1;
    showTextInput();
}

// ================= TEXT INPUT =================
function showTextInput() {
    const chat = document.getElementById("chatContainer");
    chat.innerHTML += `
        <div id="inputBox">
            <input id="userInput" placeholder="Type here...">
            <button onclick="handleMessage()">Send</button>
        </div>
    `;
    chat.scrollTop = chat.scrollHeight;
}

function handleMessage() {
    const input = document.getElementById("userInput");
    if (!input.value.trim()) return;

    appendUser(input.value);
    document.getElementById("inputBox").remove();

    if (step === 1) {
        appointment.name = input.value;
        appendBot("What date would you like your appointment?");
        showDatePicker();
        step = 2;
    } else if (step === 4) {
        appointment.service = input.value;
        confirmAppointment();
    }
}

// ================= DATE PICKER =================
function showDatePicker() {
    const chat = document.getElementById("chatContainer");
    chat.innerHTML += `
        <div id="dateBox">
            <input type="date" id="datePicker">
            <button onclick="selectDate()">Select Date</button>
        </div>
    `;
    chat.scrollTop = chat.scrollHeight;
}

function selectDate() {
    const d = document.getElementById("datePicker").value;
    if (!d) return alert("Please select a date");

    const date = new Date(d);
    appointment.date = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
    appendUser(appointment.date);

    document.getElementById("dateBox").remove();

    appendBot("Select your preferred time:");
    showTimeButtons();
    step = 3;
}

// ================= TIME BUTTONS =================
function showTimeButtons() {
    const chat = document.getElementById("chatContainer");
    chat.innerHTML += `
        <div id="timeBox">
            <button onclick="selectTime('7:00 AM')">7:00 AM</button>
            <button onclick="selectTime('8:00 AM')">8:00 AM</button>
            <button onclick="selectTime('9:00 AM')">9:00 AM</button>
            <button onclick="selectTime('10:00 AM')">10:00 AM</button>
            <button onclick="selectTime('11:00 AM')">11:00 AM</button>
            <button onclick="selectTime('12:00 PM')">12:00 PM</button>
            <button onclick="selectTime('1:00 PM')">1:00 PM</button>
            <button onclick="selectTime('2:00 PM')">2:00 PM</button>
            <button onclick="selectTime('3:00 PM')">3:00 PM</button>
            <button onclick="selectTime('4:00 PM')">4:00 PM</button>
            <button onclick="selectTime('5:00 PM')">5:00 PM</button>
        </div>
    `;
    chat.scrollTop = chat.scrollHeight;
}

function selectTime(time) {
    appointment.time = time;
    appendUser(time);
    document.getElementById("timeBox").remove();

    appendBot("What is the cause or type of service?");
    showServiceButtons();
    step = 4;
}

// ================= SERVICE BUTTONS =================
function showServiceButtons() {
    const chat = document.getElementById("chatContainer");
    chat.innerHTML += `
        <div id="serviceBox">
            <button onclick="selectService('Meeting')">Meeting</button>
            <button onclick="selectService('Violation')">Violation</button>
            <button onclick="selectService('Requirements')">Requirements</button>
            <button onclick="selectOtherService()">Other</button>
        </div>
    `;
    chat.scrollTop = chat.scrollHeight;
}

function selectService(service) {
    appointment.service = service;
    appendUser(service);
    document.getElementById("serviceBox").remove();
    confirmAppointment();
}

function selectOtherService() {
    document.getElementById("serviceBox").remove();
    appendBot("Please type your concern:");
    showTextInput();
}

// ================= CONFIRMATION =================
function confirmAppointment() {
    appendBot(
`✅ Appointment Confirmed!
Name: ${appointment.name}
Date: ${appointment.date}
Time: ${appointment.time}
Service: ${appointment.service}`
    );

    // Send appointment to Java servlet
    fetch("SendSurvey", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(appointment)
    })
    .then(response => response.text())
    .then(data => appendBot(data))
    .catch(err => appendBot("Error sending appointment."))
}

// ================= AUTO LOGIN =================
window.onload = () => {
    if (localStorage.getItem("mbcUser")) showDashboard();
};